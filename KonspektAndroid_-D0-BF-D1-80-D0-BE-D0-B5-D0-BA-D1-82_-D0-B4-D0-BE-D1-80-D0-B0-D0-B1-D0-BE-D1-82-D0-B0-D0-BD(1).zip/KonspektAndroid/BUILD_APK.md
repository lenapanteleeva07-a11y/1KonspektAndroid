# Сборка APK приложения «Конспект»

## Автоматическая сборка через GitHub Actions

В репозитории настроен workflow `.github/workflows/android-apk.yml`, который устанавливает Java 17, Gradle 8.11.1 и Android SDK Platform 36, а затем выполняет `gradle assembleDebug`.

1. Создайте репозиторий GitHub и загрузите в него **содержимое** папки `KonspektAndroid`.
2. Откройте вкладку **Actions** и выберите **Build Android APK**.
3. Нажмите **Run workflow**.
4. Дождитесь успешного завершения задания.
5. В блоке Artifacts скачайте `Konspekt-debug-apk.zip`; внутри находится `app-debug.apk`.
6. Перенесите APK на планшет HONOR Pad X8a и откройте его. При необходимости разрешите установку приложений из этого источника в настройках Android.

## Сборка в Android Studio

Требуются Android Studio, JDK 17, Android SDK Platform 36 и Build Tools 36.0.0. Откройте папку проекта, дождитесь Gradle Sync и выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Результат: `app/build/outputs/apk/debug/app-debug.apk`.

## Текущий статус и ограничения

- Проект содержит исходный код приложения и workflow автоматической сборки.
- APK в этом архиве **не собран и не проверен**: в среде подготовки нет Android SDK/Gradle, а сетевой доступ для установки зависимостей отсутствует.
- Debug APK предназначен для установки и тестирования. Для публикации в магазине потребуется подписанная release-сборка.
