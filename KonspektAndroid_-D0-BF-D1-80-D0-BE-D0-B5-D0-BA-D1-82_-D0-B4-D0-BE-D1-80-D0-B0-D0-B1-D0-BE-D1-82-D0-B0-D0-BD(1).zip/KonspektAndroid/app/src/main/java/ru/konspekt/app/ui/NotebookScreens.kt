package ru.konspekt.app.ui

import kotlinx.coroutines.withContext

import kotlinx.coroutines.Dispatchers

import androidx.compose.material.icons.filled.Save

import androidx.compose.material.icons.filled.AddPhotoAlternate

import androidx.compose.material.icons.filled.TextFields

import android.graphics.BitmapFactory

import androidx.compose.ui.graphics.asImageBitmap

import androidx.compose.ui.unit.sp

import androidx.compose.ui.text.font.FontWeight

import androidx.compose.ui.text.TextStyle

import androidx.compose.foundation.text.BasicTextField

import androidx.compose.foundation.layout.offset

import androidx.compose.foundation.Image

import android.net.Uri

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import ru.konspekt.app.data.NotePage
import ru.konspekt.app.data.Notebook
import ru.konspekt.app.data.NotebookDao
import kotlinx.coroutines.launch
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import ru.konspekt.app.export.PageExporter

private val Lilac = Color(0xFFEDE7F6)
private val Ink = Color(0xFF51456A)
private val Pink = Color(0xFFFCE4EC)

@OptIn(ExperimentalMaterial3Api::class)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotebookApp(dao: NotebookDao) {
    val scope = rememberCoroutineScope()
    val notebooks by dao.observeNotebooks().collectAsState(initial = emptyList())
    var selectedNotebook by remember { mutableStateOf<Notebook?>(null) }
    var selectedPage by remember { mutableStateOf<NotePage?>(null) }
    val pages = selectedNotebook?.let { dao.observePages(it.id).collectAsState(initial = emptyList()).value } ?: emptyList()
    var showCreateNotebook by remember { mutableStateOf(false) }
    var showCreatePage by remember { mutableStateOf(false) }
    var dialogName by remember { mutableStateOf("") }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Ink,
            secondary = Color(0xFF8C789F),
            background = Color(0xFFFFFBFF),
            surface = Color(0xFFFFFBFF)
        )
    ) {
        when {
            selectedPage != null -> PageEditor(
                page = selectedPage!!,
                onBack = { selectedPage = null },
                onTemplate = { template ->
                    scope.launch {
                        val updated = selectedPage!!.copy(template = template, updatedAt = System.currentTimeMillis())
                        dao.updatePage(updated)
                        selectedPage = updated
                    }
                },
                onStrokesChanged = { strokes ->
                    val current = selectedPage ?: return@PageEditor
                    val updated = current.copy(strokes = strokes, updatedAt = System.currentTimeMillis())
                    selectedPage = updated
                    scope.launch { dao.updatePage(updated) }
                },
                onPageChanged = { updated ->
                    selectedPage = updated
                    scope.launch { dao.updatePage(updated) }
                }
            )
            selectedNotebook != null -> {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text(selectedNotebook!!.title) },
                            navigationIcon = { IconButton(onClick = { selectedNotebook = null }) { Icon(Icons.Default.ArrowBack, "Назад") } },
                            actions = {
                                IconButton(onClick = { showCreatePage = true }) { Icon(Icons.Default.Add, "Добавить страницу") }
                            }
                        )
                    },
                    floatingActionButton = {
                        FloatingActionButton(onClick = { showCreatePage = true }) { Icon(Icons.Default.Add, "Новая страница") }
                    }
                ) { padding ->
                    if (pages.isEmpty()) {
                        EmptyState("В этой тетради пока нет страниц", "Нажми +, чтобы создать первую страницу", Modifier.padding(padding))
                    } else {
                        LazyColumn(contentPadding = padding, modifier = Modifier.fillMaxSize()) {
                            items(pages, key = { it.id }) { page ->
                                Card(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                                        .clickable { selectedPage = page },
                                    colors = CardDefaults.cardColors(containerColor = if (page.template == "Чистый лист") Color.White else Lilac.copy(alpha = .45f))
                                ) {
                                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(page.title, style = MaterialTheme.typography.titleMedium)
                                            Text(page.template, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        }
                                        IconButton(onClick = { scope.launch { dao.deletePage(page) } }) { Icon(Icons.Default.Delete, "Удалить страницу") }
                                    }
                                }
                            }
                        }
                    }
                }
                if (showCreatePage) {
                    NameDialog("Новая страница", "Например, Тема урока", dialogName,
                        onName = { dialogName = it },
                        onDismiss = { showCreatePage = false; dialogName = "" },
                        onConfirm = {
                            val name = dialogName.ifBlank { "Страница ${pages.size + 1}" }
                            scope.launch {
                                val id = dao.insertPage(NotePage(notebookId = selectedNotebook!!.id, title = name))
                                selectedPage = NotePage(id = id, notebookId = selectedNotebook!!.id, title = name)
                            }
                            showCreatePage = false
                            dialogName = ""
                        })
                }
            }
            else -> {
                Scaffold(
                    topBar = { TopAppBar(title = { Text("Конспект", style = MaterialTheme.typography.headlineSmall) }) },
                    floatingActionButton = {
                        FloatingActionButton(onClick = { showCreateNotebook = true }) { Icon(Icons.Default.Add, "Создать тетрадь") }
                    }
                ) { padding ->
                    if (notebooks.isEmpty()) {
                        EmptyState("Твои конспекты начинаются здесь", "Создай первую тетрадь — страницы будут храниться на планшете.", Modifier.padding(padding))
                    } else {
                        LazyColumn(contentPadding = padding, modifier = Modifier.fillMaxSize()) {
                            items(notebooks, key = { it.id }) { notebook ->
                                Card(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp)
                                        .clickable { selectedNotebook = notebook },
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = if (notebook.id % 2L == 0L) Lilac else Pink)
                                ) {
                                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            Modifier.size(52.dp).background(Color.White.copy(alpha = .75f), RoundedCornerShape(14.dp)),
                                            contentAlignment = Alignment.Center
                                        ) { Icon(Icons.Default.Edit, null, tint = Ink) }
                                        Spacer(Modifier.width(14.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(notebook.title, style = MaterialTheme.typography.titleMedium, color = Ink)
                                            Text("Локальная тетрадь", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = .7f))
                                        }
                                        IconButton(onClick = {
                                            scope.launch {
                                                dao.deletePagesForNotebook(notebook.id)
                                                dao.deleteNotebook(notebook)
                                            }
                                        }) { Icon(Icons.Default.Delete, "Удалить тетрадь") }
                                    }
                                }
                            }
                        }
                    }
                }
                if (showCreateNotebook) {
                    NameDialog("Новая тетрадь", "Название тетради", dialogName,
                        onName = { dialogName = it },
                        onDismiss = { showCreateNotebook = false; dialogName = "" },
                        onConfirm = {
                            val title = dialogName.ifBlank { "Новая тетрадь" }
                            scope.launch { dao.insertNotebook(Notebook(title = title)) }
                            showCreateNotebook = false
                            dialogName = ""
                        })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PageEditor(
    page: NotePage,
    onBack: () -> Unit,
    onTemplate: (String) -> Unit,
    onStrokesChanged: (String) -> Unit,
    onPageChanged: (NotePage) -> Unit
) {
    var color by remember { mutableStateOf(Color(0xFF34313D)) }
    var width by remember { mutableFloatStateOf(4f) }
    var eraser by remember { mutableStateOf(false) }
    var undoSignal by remember { mutableIntStateOf(0) }
    var showTools by remember { mutableStateOf(false) }
    val templates = listOf("Чистый лист", "Клетка", "Линейка", "Точки")
    val context = LocalContext.current
    var textDraft by remember(page.id) { mutableStateOf(page.textBlocks) }
    var showTextEditor by remember { mutableStateOf(false) }
    var images by remember(page.id) { mutableStateOf(page.imageUris.split("\\n").filter { it.isNotBlank() }) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val next = (images + uri.toString()).distinct()
            images = next
            onPageChanged(page.copy(imageUris = next.joinToString("\\n"), updatedAt = System.currentTimeMillis()))
        }
    }
    val pngLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) runCatching { PageExporter.writePng(context, uri, page) }
            .onSuccess { Toast.makeText(context, "PNG сохранён", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(context, "Ошибка экспорта PNG: ${it.message}", Toast.LENGTH_LONG).show() }
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) runCatching { PageExporter.writePdf(context, uri, page) }
            .onSuccess { Toast.makeText(context, "PDF сохранён", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(context, "Ошибка экспорта PDF: ${it.message}", Toast.LENGTH_LONG).show() }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(page.title, maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад") } },
                actions = {
                    IconButton(onClick = { undoSignal++ }) { Icon(Icons.Default.Undo, "Отменить последний штрих") }
                    IconButton(onClick = { showTextEditor = !showTextEditor }) { Icon(Icons.Default.TextFields, "Текст") }
                    IconButton(onClick = { imagePicker.launch(arrayOf("image/*")) }) { Icon(Icons.Default.AddPhotoAlternate, "Добавить изображение") }
                    IconButton(onClick = { showTools = !showTools }) { Icon(Icons.Default.Palette, "Инструменты") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (showTextEditor) {
                Column(Modifier.fillMaxWidth().background(Pink.copy(alpha = .55f)).padding(12.dp)) {
                    Text("Печатный текст", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(
                        value = textDraft,
                        onValueChange = { textDraft = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Введи определение, тему или объяснение…") },
                        minLines = 2,
                        maxLines = 5
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = {
                            val updated = page.copy(textBlocks = textDraft, updatedAt = System.currentTimeMillis())
                            onPageChanged(updated)
                            showTextEditor = false
                        }) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(4.dp)); Text("Сохранить текст") }
                    }
                }
            }
            if (showTools) {
                Column(Modifier.fillMaxWidth().background(Lilac.copy(alpha = .55f)).padding(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf(Color(0xFF34313D), Color(0xFF6D4C41), Color(0xFF1565C0), Color(0xFF2E7D32), Color(0xFFC62828), Color(0xFF8E24AA)).forEach { c ->
                            Surface(
                                modifier = Modifier.size(30.dp).clickable { color = c; eraser = false },
                                shape = RoundedCornerShape(50),
                                color = c,
                                border = if (color == c && !eraser) androidx.compose.foundation.BorderStroke(3.dp, Color.White) else null
                            ) {}
                        }
                        TextButton(onClick = { eraser = !eraser }) { Text(if (eraser) "Перо" else "Ластик") }
                    }
                    Text("Толщина пера: ${width.toInt()}")
                    Slider(value = width, onValueChange = { width = it }, valueRange = 2f..14f)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        templates.forEach { template ->
                            FilterChip(
                                selected = page.template == template,
                                onClick = { onTemplate(template) },
                                label = { Text(template) }
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pngLauncher.launch("${page.title}.png") }) {
                            Icon(Icons.Default.Image, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Экспорт PNG")
                        }
                        OutlinedButton(onClick = { pdfLauncher.launch("${page.title}.pdf") }) {
                            Icon(Icons.Default.PictureAsPdf, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Экспорт PDF")
                        }
                    }
                }
            }
            Box(Modifier.fillMaxSize().padding(12.dp)) {
                InkCanvas(
                    page = page,
                    inkColor = color,
                    inkWidth = width,
                    eraser = eraser,
                    undoSignal = undoSignal,
                    onStrokesChanged = onStrokesChanged,
                    modifier = Modifier.fillMaxSize()
                )
                // Text and inserted pictures remain visible on the page, not only in the editor.
                Column(Modifier.fillMaxWidth().padding(10.dp)) {
                    if (page.textBlocks.isNotBlank()) {
                        Surface(color = Color.White.copy(alpha = 0.92f), shape = RoundedCornerShape(8.dp)) {
                            Text(page.textBlocks, modifier = Modifier.fillMaxWidth().padding(8.dp), color = Color(0xFF25232A))
                        }
                    }
                    if (images.isNotEmpty()) {
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            images.take(3).forEach { imageUri ->
                                PageImageThumbnail(imageUri, Modifier.weight(1f).height(110.dp))
                            }
                        }
                        if (images.size > 3) Text("Ещё изображений: ${images.size - 3}", color = Color.DarkGray, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun PageImageThumbnail(uriString: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(null, uriString) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(Uri.parse(uriString))?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
        }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Добавленное изображение", modifier = modifier, contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    } else {
        Surface(modifier = modifier, color = Lilac.copy(alpha = .5f), shape = RoundedCornerShape(8.dp)) {
            Box(contentAlignment = Alignment.Center) { Text("Изображение", style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
    }
}

@Composable
private fun NameDialog(
    title: String,
    placeholder: String,
    value: String,
    onName: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = onName,
                placeholder = { Text(placeholder) },
                singleLine = true
            )
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Создать") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
