package ru.konspekt.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notebooks")
data class Notebook(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "pages")
data class NotePage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val notebookId: Long,
    val title: String,
    val template: String = "Чистый лист",
    // Stored as: stroke|stroke; stroke = x,y,x,y,...; all coordinates are normalized to 0..1.
    val strokes: String = "",
    val textBlocks: String = "",
    val imageUris: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
