package ru.konspekt.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface NotebookDao {
    @Query("SELECT * FROM notebooks ORDER BY createdAt DESC")
    fun observeNotebooks(): Flow<List<Notebook>>

    @Insert
    suspend fun insertNotebook(notebook: Notebook): Long

    @Delete
    suspend fun deleteNotebook(notebook: Notebook)

    @Query("SELECT * FROM pages WHERE notebookId = :notebookId ORDER BY id ASC")
    fun observePages(notebookId: Long): Flow<List<NotePage>>

    @Insert
    suspend fun insertPage(page: NotePage): Long

    @Update
    suspend fun updatePage(page: NotePage)

    @Delete
    suspend fun deletePage(page: NotePage)

    @Query("DELETE FROM pages WHERE notebookId = :notebookId")
    suspend fun deletePagesForNotebook(notebookId: Long)
}
