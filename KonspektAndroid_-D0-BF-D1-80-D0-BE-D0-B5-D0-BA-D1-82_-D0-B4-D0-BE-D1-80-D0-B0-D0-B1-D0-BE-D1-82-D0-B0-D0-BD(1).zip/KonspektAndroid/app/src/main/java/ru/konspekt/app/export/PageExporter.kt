package ru.konspekt.app.export

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.content.Context
import ru.konspekt.app.data.NotePage
import ru.konspekt.app.ui.decodeStrokes
import androidx.compose.ui.graphics.toArgb
import java.io.OutputStream

object PageExporter {
    private const val PAGE_WIDTH = 1200
    private const val PAGE_HEIGHT = 1600

    fun render(context: Context, page: NotePage): Bitmap {
        val bitmap = Bitmap.createBitmap(PAGE_WIDTH, PAGE_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(AndroidColor.WHITE)
        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.rgb(220, 228, 240)
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }
        when (page.template) {
            "Клетка" -> {
                var x = 0f
                while (x <= PAGE_WIDTH) { canvas.drawLine(x, 0f, x, PAGE_HEIGHT.toFloat(), gridPaint); x += 48f }
                var y = 0f
                while (y <= PAGE_HEIGHT) { canvas.drawLine(0f, y, PAGE_WIDTH.toFloat(), y, gridPaint); y += 48f }
            }
            "Линейка" -> {
                gridPaint.color = AndroidColor.rgb(232, 191, 200)
                var y = 64f
                while (y <= PAGE_HEIGHT) { canvas.drawLine(0f, y, PAGE_WIDTH.toFloat(), y, gridPaint); y += 64f }
                canvas.drawLine(96f, 0f, 96f, PAGE_HEIGHT.toFloat(), gridPaint)
            }
            "Точки" -> {
                val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AndroidColor.rgb(203, 208, 218) }
                var y = 44f
                while (y < PAGE_HEIGHT) {
                    var x = 44f
                    while (x < PAGE_WIDTH) { canvas.drawCircle(x, y, 2.5f, dotPaint); x += 44f }
                    y += 44f
                }
            }
        }
        // Include typed notes and attached images in exports as well as handwriting.
        if (page.textBlocks.isNotBlank()) {
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = AndroidColor.rgb(37, 35, 42)
                textSize = 32f
            }
            var y = 90f
            val maxWidth = PAGE_WIDTH - 120f
            page.textBlocks.lines().forEach { line ->
                var remaining = line
                while (remaining.isNotEmpty()) {
                    var end = remaining.length
                    while (end > 1 && textPaint.measureText(remaining.substring(0, end)) > maxWidth) end--
                    if (end < remaining.length) {
                        val space = remaining.lastIndexOf(' ', end)
                        if (space > 0) end = space
                    }
                    canvas.drawText(remaining.substring(0, end), 60f, y, textPaint)
                    remaining = remaining.substring(end).trimStart()
                    y += 42f
                }
                y += 8f
            }
        }
        val imageUris = page.imageUris.split("\\n").filter { it.isNotBlank() }.take(3)
        if (imageUris.isNotEmpty()) {
            val cellWidth = (PAGE_WIDTH - 120f) / imageUris.size
            imageUris.forEachIndexed { index, uriString ->
                runCatching {
                    context.contentResolver.openInputStream(Uri.parse(uriString))?.use { BitmapFactory.decodeStream(it) }
                }.getOrNull()?.let { image ->
                    val maxW = cellWidth - 16f
                    val maxH = 360f
                    val scale = minOf(maxW / image.width, maxH / image.height, 1f)
                    val w = image.width * scale
                    val h = image.height * scale
                    val left = 60f + index * cellWidth + (cellWidth - w) / 2f
                    canvas.drawBitmap(image, null, android.graphics.RectF(left, 260f, left + w, 260f + h), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                    image.recycle()
                }
            }
        }
        val strokes = decodeStrokes(page.strokes)
        strokes.forEach { stroke ->
            if (stroke.points.isNotEmpty()) {
                val path = Path()
                val first = stroke.points.first()
                path.moveTo(first.x * PAGE_WIDTH, first.y * PAGE_HEIGHT)
                stroke.points.drop(1).forEach { path.lineTo(it.x * PAGE_WIDTH, it.y * PAGE_HEIGHT) }
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (stroke.erase) AndroidColor.WHITE else stroke.color.toArgb()
                    style = Paint.Style.STROKE
                    strokeWidth = stroke.width * (PAGE_WIDTH / 400f)
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                }
                canvas.drawPath(path, paint)
            }
        }
        return bitmap
    }

    fun writePng(context: Context, uri: Uri, page: NotePage) {
        val bitmap = render(context, page)
        context.contentResolver.openOutputStream(uri)?.use { stream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        } ?: error("Не удалось открыть файл для записи")
        bitmap.recycle()
    }

    fun writePdf(context: Context, uri: Uri, page: NotePage) {
        val bitmap = render(context, page)
        val document = PdfDocument()
        val info = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val pdfPage = document.startPage(info)
        pdfPage.canvas.drawBitmap(bitmap, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG))
        document.finishPage(pdfPage)
        try {
            context.contentResolver.openOutputStream(uri)?.use { document.writeTo(it) }
                ?: error("Не удалось открыть файл для записи")
        } finally {
            document.close()
            bitmap.recycle()
        }
    }
}
