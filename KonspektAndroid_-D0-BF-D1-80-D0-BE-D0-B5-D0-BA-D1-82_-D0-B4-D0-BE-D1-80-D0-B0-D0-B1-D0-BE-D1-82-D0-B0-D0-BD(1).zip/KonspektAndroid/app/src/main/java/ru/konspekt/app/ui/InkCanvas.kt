package ru.konspekt.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import ru.konspekt.app.data.NotePage
import kotlin.math.max

data class InkStroke(
    val points: List<Offset>,
    val color: Color,
    val width: Float,
    val erase: Boolean = false
)

fun encodeStrokes(strokes: List<InkStroke>): String = strokes.joinToString("|") { s ->
    val head = "${s.color.value.toULong().toString(16)},${s.width},${if (s.erase) 1 else 0}"
    head + ";" + s.points.joinToString(";") { "${it.x},${it.y}" }
}

fun decodeStrokes(raw: String): List<InkStroke> {
    if (raw.isBlank()) return emptyList()
    return raw.split("|").mapNotNull { part ->
        runCatching {
            val chunks = part.split(";")
            val meta = chunks.first().split(",")
            val color = Color(meta[0].toULong(16).toLong())
            val width = meta[1].toFloat()
            val erase = meta[2] == "1"
            val pts = chunks.drop(1).mapNotNull { pair ->
                val xy = pair.split(",")
                if (xy.size != 2) null else Offset(xy[0].toFloat(), xy[1].toFloat())
            }
            InkStroke(pts, color, width, erase)
        }.getOrNull()
    }
}

@Composable
fun InkCanvas(
    page: NotePage,
    inkColor: Color,
    inkWidth: Float,
    eraser: Boolean,
    undoSignal: Int,
    onStrokesChanged: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strokes = remember(page.id) { mutableStateListOf<InkStroke>().apply { addAll(decodeStrokes(page.strokes)) } }
    val currentPoints = remember { mutableStateListOf<Offset>() }

    LaunchedEffect(undoSignal) {
        if (undoSignal > 0 && strokes.isNotEmpty()) {
            strokes.removeAt(strokes.lastIndex)
            onStrokesChanged(encodeStrokes(strokes))
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(inkColor, inkWidth, eraser, page.id) {
                detectDragGestures(
                    onDragStart = { start ->
                        currentPoints.clear()
                        currentPoints.add(Offset(
                            (start.x / size.width).coerceIn(0f, 1f),
                            (start.y / size.height).coerceIn(0f, 1f)
                        ))
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        currentPoints.add(Offset(
                            (change.position.x / size.width).coerceIn(0f, 1f),
                            (change.position.y / size.height).coerceIn(0f, 1f)
                        ))
                    },
                    onDragEnd = {
                        if (currentPoints.isNotEmpty()) {
                            strokes.add(InkStroke(currentPoints.toList(), inkColor, inkWidth, eraser))
                            currentPoints.clear()
                            onStrokesChanged(encodeStrokes(strokes))
                        }
                    },
                    onDragCancel = { currentPoints.clear() }
                )
            }
    ) {
        drawRect(Color.White)
        when (page.template) {
            "Клетка" -> {
                val step = 24.dp.toPx()
                var x = 0f
                while (x <= size.width) {
                    drawLine(Color(0xFFDCE4F0), Offset(x, 0f), Offset(x, size.height), 1f)
                    x += step
                }
                var y = 0f
                while (y <= size.height) {
                    drawLine(Color(0xFFDCE4F0), Offset(0f, y), Offset(size.width, y), 1f)
                    y += step
                }
            }
            "Линейка" -> {
                val step = 32.dp.toPx()
                var y = step
                while (y <= size.height) {
                    drawLine(Color(0xFFE8BFC8), Offset(0f, y), Offset(size.width, y), 1f)
                    y += step
                }
                drawLine(Color(0xFFE8BFC8), Offset(48.dp.toPx(), 0f), Offset(48.dp.toPx(), size.height), 1.2f)
            }
            "Точки" -> {
                val step = 22.dp.toPx()
                var y = step
                while (y < size.height) {
                    var x = step
                    while (x < size.width) {
                        drawCircle(Color(0xFFCBD0DA), radius = 1.2.dp.toPx(), center = Offset(x, y))
                        x += step
                    }
                    y += step
                }
            }
        }

        val all = strokes.toList() + if (currentPoints.isNotEmpty()) listOf(InkStroke(currentPoints.toList(), inkColor, inkWidth, eraser)) else emptyList()
        all.forEach { stroke ->
            if (stroke.points.isNotEmpty()) {
                val path = Path()
                val first = stroke.points.first()
                path.moveTo(first.x * size.width, first.y * size.height)
                stroke.points.drop(1).forEach { path.lineTo(it.x * size.width, it.y * size.height) }
                drawPath(
                    path = path,
                    color = if (stroke.erase) Color.White else stroke.color,
                    style = Stroke(width = max(1f, stroke.width), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
    }
}

