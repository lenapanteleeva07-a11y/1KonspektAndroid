package ru.konspekt.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import ru.konspekt.app.data.AppDatabase
import ru.konspekt.app.ui.NotebookApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDatabase.get(applicationContext).notebookDao()
        setContent {
            androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
                NotebookApp(dao)
            }
        }
    }
}
